<?php require "includes/header.php"; ?>

<?php /*echo 

    "hello " .$_SESSION['username']; 

*/

?>

<?php require "includes/footer.php"; ?>
